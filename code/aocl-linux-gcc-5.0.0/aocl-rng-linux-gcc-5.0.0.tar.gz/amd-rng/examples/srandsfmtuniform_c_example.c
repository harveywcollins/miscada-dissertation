
/* sranduniform SFMT19937 as BRNG Example Program Text */
/*
 * Copyright (C) 2023 Advanced Micro Devices, Inc. All rights reserved.
 */

#include <rng.h>
#include <stdio.h>


#define MN     12
#define MSTATE 637
#define MSEED  624

rng_int_t seed[MSEED], state[MSTATE];
float    x[MN];

int main(void)
{
  const int mn = MN;
  float a, b;
  rng_int_t n, genid, subid, lseed, lstate, info;


  printf("\n");
  printf("--RNG-example: sfmt uniform random numbers using sranduniform--\n");
  printf("---------------------------------------------------------------\n");
  printf("\n");

  /* Initialize the number of variates required */
  n = mn;

  /* Use SFMT19937 Generator as the base generator */
  genid = 6;
  subid = 1;

  lstate  = MSTATE;
  lseed   = 1;
  seed[0] = 122421;

  /* Initialize the base generator */
  srandinitialize(genid, subid, seed, &lseed, state, &lstate, &info);

  /* Generate a sequence from a uniform U(0,1) distribution */
  a = 0.0f;
  b = 1.0f;

  sranduniform(n, a, b, state, x, &info);

  /* Print the sequence */
  printf("Numbers from a SFMT uniform U(0,1) distribution:\n");

  for (int i=0; i<n; i++) {
    printf("%10.4f", x[i]);

    if ((i+1)%4 == 0)
      printf("\n");
  }

  printf("\n");

  return 0;
}
